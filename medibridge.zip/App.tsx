import React from 'react';
import { StatusBar } from 'expo-status-bar';
import { SafeAreaProvider } from 'react-native-safe-area-context';
import { AuthProvider } from './src/context/AuthContext';
import { BloodProvider } from './src/context/BloodContext';
import { AppNavigator } from './src/navigation/AppNavigator';

export default function App() {
  return (
    <SafeAreaProvider>
      <AuthProvider>
        <BloodProvider>
          <AppNavigator />
          <StatusBar style="dark" />
        </BloodProvider>
      </AuthProvider>
    </SafeAreaProvider>
  );
}
