import { Platform } from 'react-native';

export const typography = {
  // Font Family
  fontFamily: Platform.select({
    ios: 'System', // Will fall back to system font if Inter isn't loaded, but we'll use system style mapping
    android: 'sans-serif',
    default: 'System',
  }),

  // Font Sizes
  sizes: {
    xs: 12,
    sm: 14,
    md: 16,
    lg: 18,
    xl: 20,
    xxl: 24,
    xxxl: 32,
  },

  // Font Weights
  weights: {
    regular: '400' as const,
    medium: '500' as const,
    semibold: '600' as const,
    bold: '700' as const,
  },

  // Line Heights
  lineHeights: {
    xs: 16,
    sm: 20,
    md: 24,
    lg: 28,
    xl: 32,
    xxl: 40,
    xxxl: 56,
  },

  // Predefined Styles matching Stitch Design System
  styles: {
    displayLg: {
      fontSize: 32, // Headline-lg-mobile fits better as primary display on standard mobile
      fontWeight: '700' as const,
      lineHeight: 40,
      letterSpacing: -0.5,
    },
    headlineLg: {
      fontSize: 24,
      fontWeight: '700' as const,
      lineHeight: 32,
    },
    headlineMd: {
      fontSize: 20,
      fontWeight: '600' as const,
      lineHeight: 28,
    },
    titleLg: {
      fontSize: 18,
      fontWeight: '600' as const,
      lineHeight: 26,
    },
    bodyLg: {
      fontSize: 18,
      fontWeight: '400' as const,
      lineHeight: 28,
    },
    bodyMd: {
      fontSize: 16,
      fontWeight: '400' as const,
      lineHeight: 24,
    },
    bodySm: {
      fontSize: 14,
      fontWeight: '400' as const,
      lineHeight: 20,
    },
    labelLg: {
      fontSize: 14,
      fontWeight: '600' as const,
      lineHeight: 20,
      letterSpacing: 0.5,
    },
    labelMd: {
      fontSize: 12,
      fontWeight: '700' as const,
      lineHeight: 16,
      letterSpacing: 0.8,
    },
  },
};

export type TypographyType = typeof typography;
