export const colors = {
  // Brand Colors
  primary: '#c62828',          // Blood Red (Emergency, Primary Actions, Blood Type)
  primaryDark: '#a20513',      // Darker Blood Red
  secondary: '#1e3a5f',        // Navy Blue (Structural Foundation, Navigation, Headers)
  tertiary: '#0d47a1',         // Accent Blue

  // Neutral Colors
  background: '#f7f9fc',       // Light Grey background
  surface: '#ffffff',          // Card/Container surface
  surfaceDim: '#d8dadd',       // Slightly darker surface
  border: '#e0e4e8',           // Subtle border
  outline: '#8f706c',          // Outline

  // Text Colors
  textPrimary: '#191c1e',      // Main body text, headings
  textSecondary: '#455f87',    // Labels, sub-headers, tertiary text
  textLight: '#ffffff',        // Light text on dark backgrounds
  textMuted: '#757575',        // Disabled or secondary muted details

  // Status Colors (Traffic light system for clinical states)
  status: {
    critical: '#c62828',       // Critical alert
    urgent: '#ff9800',         // Urgent alert (Orange)
    normal: '#1e3a5f',         // Standard/Safe (Navy)
    success: '#4caf50',        // Complete/Delivered (Green)
  },

  // Interactive
  overlay: 'rgba(0, 0, 0, 0.4)',
  ripple: 'rgba(198, 40, 40, 0.1)',
};

export type ColorsType = typeof colors;
