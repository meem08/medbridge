import React, { useEffect } from 'react';
import { View, Text, StyleSheet, ActivityIndicator } from 'react-native';
import { colors, spacing, typography } from '../../theme';
import { useNavigation } from '@react-navigation/native';
import { StackNavigationProp } from '@react-navigation/stack';

type RootStackParamList = {
  Splash: undefined;
  ChooseRole: undefined;
  Login: { role: 'hospital' | 'donor' };
  HospitalMain: undefined;
  DonorMain: undefined;
};

type NavigationProp = StackNavigationProp<RootStackParamList, 'Splash'>;

export const SplashScreen: React.FC = () => {
  const navigation = useNavigation<NavigationProp>();

  useEffect(() => {
    const timer = setTimeout(() => {
      navigation.replace('ChooseRole');
    }, 1500);

    return () => clearTimeout(timer);
  }, [navigation]);

  return (
    <View style={styles.container}>
      <View style={styles.logoContainer}>
        {/* Simple geometric clinical-styled icon */}
        <View style={styles.iconCircle}>
          <View style={styles.iconCrossVertical} />
          <View style={styles.iconCrossHorizontal} />
          <View style={styles.dropShape} />
        </View>
        <Text style={styles.title}>MEDI<Text style={styles.titleAccent}>BRIDGE</Text></Text>
        <Text style={styles.subtitle}>Emergency Blood Coordination AI</Text>
      </View>

      <ActivityIndicator size="small" color={colors.primary} style={styles.loader} />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background,
    justifyContent: 'center',
    alignItems: 'center',
  },
  logoContainer: {
    alignItems: 'center',
  },
  iconCircle: {
    width: 64,
    height: 64,
    borderRadius: 32,
    backgroundColor: colors.primary,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: spacing.md,
    position: 'relative',
  },
  iconCrossVertical: {
    width: 6,
    height: 32,
    backgroundColor: colors.textLight,
    borderRadius: 3,
    position: 'absolute',
  },
  iconCrossHorizontal: {
    width: 32,
    height: 6,
    backgroundColor: colors.textLight,
    borderRadius: 3,
    position: 'absolute',
  },
  dropShape: {
    width: 12,
    height: 12,
    borderRadius: 6,
    backgroundColor: colors.textLight,
    position: 'absolute',
    transform: [{ rotate: '45deg' }],
    borderTopLeftRadius: 0,
    bottom: 16,
    right: 16,
  },
  title: {
    ...typography.styles.displayLg,
    color: colors.secondary,
    letterSpacing: 2,
  },
  titleAccent: {
    color: colors.primary,
  },
  subtitle: {
    ...typography.styles.labelLg,
    color: colors.textSecondary,
    marginTop: spacing.xs,
    fontSize: 12,
  },
  loader: {
    position: 'absolute',
    bottom: spacing.xxl,
  },
});
