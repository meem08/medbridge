import React from 'react';
import {
  View,
  Text,
  StyleSheet,
  SafeAreaView,
  ScrollView,
  TouchableOpacity,
} from 'react-native';
import { colors, spacing, typography } from '../../theme';
import { Card } from '../../components/Card';
import { Button } from '../../components/Button';
import { Badge } from '../../components/Badge';
import { useAuth } from '../../context/AuthContext';
import { useBlood } from '../../context/BloodContext';
import { useNavigation } from '@react-navigation/native';
import { StackNavigationProp } from '@react-navigation/stack';
import { formatDate } from '../../utils/formatters';

type DonorParamList = {
  DonorDashboard: undefined;
  BookAppointment: undefined;
  DonationHistory: undefined;
  ChooseRole: undefined;
};

type NavigationProp = StackNavigationProp<DonorParamList, 'DonorDashboard'>;

export const DonorDashboard: React.FC = () => {
  const navigation = useNavigation<NavigationProp>();
  const { user, logout } = useAuth();
  const { requests } = useBlood();

  const handleLogout = () => {
    logout();
    navigation.getParent()?.navigate('ChooseRole');
  };

  // Find any active critical requests that match O- or A- (universal or critical types)
  const criticalRequests = requests.filter(
    (req) => req.urgency === 'critical' && req.status === 'pending'
  );

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.header}>
        <View>
          <Text style={styles.welcomeText}>VOLUNTEER DONOR</Text>
          <Text style={styles.donorName} numberOfLines={1}>
            {user?.name || 'Tinashe Pharaoh'}
          </Text>
        </View>
        <TouchableOpacity onPress={handleLogout} style={styles.logoutBtn}>
          <Text style={styles.logoutText}>Log Out</Text>
        </TouchableOpacity>
      </View>

      <ScrollView contentContainerStyle={styles.scrollContent}>
        {/* Donor Impact Stats Card */}
        <Card style={styles.impactCard} isLowStock={false}>
          <Text style={styles.cardLabel}>YOUR DONOR PROFILE</Text>
          <View style={styles.bloodTypeContainer}>
            <Text style={styles.bloodLabel}>Blood Type</Text>
            <View style={styles.bloodBadge}>
              <Text style={styles.bloodBadgeText}>O-</Text>
            </View>
          </View>

          <View style={styles.statsRow}>
            <View style={styles.statCol}>
              <Text style={styles.statNum}>3</Text>
              <Text style={styles.statLabel}>Donations</Text>
            </View>
            <View style={[styles.statCol, styles.statColBorder]}>
              <Text style={styles.statNum}>9</Text>
              <Text style={styles.statLabel}>Lives Saved</Text>
            </View>
            <View style={styles.statCol}>
              <Text style={styles.statNum}>Yes</Text>
              <Text style={styles.statLabel}>Eligible Now</Text>
            </View>
          </View>
        </Card>

        {/* Urgent Emergency Call to Action */}
        {criticalRequests.length > 0 ? (
          <Card style={styles.alertCard} isLowStock={true}>
            <Text style={styles.alertTitle}>🚨 IMMEDIATE ACTION REQUIRED</Text>
            <Text style={styles.alertDesc}>
              There are active emergency blood requests in your region. Your blood type (O Negative) is the universal donor type and is highly needed.
            </Text>
            <Button
              title="Respond to Request"
              onPress={() => navigation.navigate('BookAppointment')}
              variant="emergency"
              style={styles.alertBtn}
            />
          </Card>
        ) : null}

        {/* Standard CTA */}
        <View style={styles.actionContainer}>
          <Text style={styles.sectionTitle}>Donate Blood</Text>
          <Text style={styles.sectionDesc}>
            Booking an appointment takes only 5 minutes. Select a time slot at your nearest donation center.
          </Text>
          <Button
            title="Schedule Appointment"
            onPress={() => navigation.navigate('BookAppointment')}
            variant="primary"
            style={styles.actionBtn}
          />
        </View>

        {/* Donation Navigation Options */}
        <View style={styles.optionsContainer}>
          <Card
            onPress={() => navigation.navigate('DonationHistory')}
            style={styles.optionCard}
          >
            <View style={styles.optionInner}>
              <Text style={styles.optionTitle}>Donation History</Text>
              <Text style={styles.optionDesc}>
                View dates, locations, and health summaries of your past donations.
              </Text>
            </View>
          </Card>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: spacing.containerPadding,
    paddingVertical: spacing.md,
    backgroundColor: colors.surface,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
  },
  welcomeText: {
    ...typography.styles.labelMd,
    color: colors.textSecondary,
  },
  donorName: {
    ...typography.styles.titleLg,
    color: colors.textPrimary,
    fontWeight: '700',
    maxWidth: 240,
  },
  logoutBtn: {
    paddingVertical: spacing.xs,
    paddingHorizontal: spacing.sm,
  },
  logoutText: {
    ...typography.styles.labelMd,
    color: colors.primary,
  },
  scrollContent: {
    padding: spacing.containerPadding,
  },
  impactCard: {
    paddingVertical: spacing.lg,
  },
  cardLabel: {
    ...typography.styles.labelMd,
    color: colors.textSecondary,
    marginBottom: spacing.sm,
  },
  bloodTypeContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: spacing.lg,
    paddingBottom: spacing.md,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
  },
  bloodLabel: {
    ...typography.styles.titleLg,
    color: colors.textPrimary,
  },
  bloodBadge: {
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: colors.primary,
    justifyContent: 'center',
    alignItems: 'center',
  },
  bloodBadgeText: {
    ...typography.styles.labelLg,
    color: colors.textLight,
    fontWeight: '700',
    fontSize: 16,
  },
  statsRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  statCol: {
    flex: 1,
    alignItems: 'center',
  },
  statColBorder: {
    borderLeftWidth: 1,
    borderLeftColor: colors.border,
    borderRightWidth: 1,
    borderRightColor: colors.border,
  },
  statNum: {
    ...typography.styles.displayLg,
    fontSize: 24,
    color: colors.secondary,
  },
  statLabel: {
    ...typography.styles.labelMd,
    fontSize: 10,
    color: colors.textSecondary,
    marginTop: spacing.xs / 2,
  },
  alertCard: {
    borderColor: colors.primary,
  },
  alertTitle: {
    ...typography.styles.titleLg,
    color: colors.primary,
    fontWeight: '700',
  },
  alertDesc: {
    ...typography.styles.bodySm,
    color: colors.textSecondary,
    marginTop: spacing.xs,
    lineHeight: 20,
  },
  alertBtn: {
    marginTop: spacing.md,
  },
  actionContainer: {
    marginVertical: spacing.md,
  },
  sectionTitle: {
    ...typography.styles.titleLg,
    color: colors.secondary,
    fontWeight: '700',
    marginBottom: spacing.xs,
  },
  sectionDesc: {
    ...typography.styles.bodySm,
    color: colors.textSecondary,
    marginBottom: spacing.md,
    lineHeight: 20,
  },
  actionBtn: {
    width: '100%',
  },
  optionsContainer: {
    marginTop: spacing.sm,
  },
  optionCard: {
    padding: spacing.md,
  },
  optionInner: {
    flexDirection: 'column',
  },
  optionTitle: {
    ...typography.styles.titleLg,
    color: colors.textPrimary,
    fontWeight: '600',
  },
  optionDesc: {
    ...typography.styles.bodySm,
    color: colors.textSecondary,
    marginTop: spacing.xs,
    lineHeight: 18,
  },
});
