import React from 'react';
import { View, Text, StyleSheet, ViewStyle, TextStyle } from 'react-native';
import { colors, spacing, typography } from '../theme';
import { UrgencyLevel, RequestStatus } from '../models/bloodRequest';

interface BadgeProps {
  type?: UrgencyLevel | RequestStatus | 'success';
  label?: string;
  style?: ViewStyle;
}

export const Badge: React.FC<BadgeProps> = ({ type = 'normal', label, style }) => {
  const getBadgeStyle = () => {
    let backgroundColor = colors.status.normal;
    let text = label || String(type).toUpperCase();

    switch (type) {
      case 'critical':
        backgroundColor = colors.status.critical;
        text = label || 'CRITICAL';
        break;
      case 'urgent':
        backgroundColor = colors.status.urgent;
        text = label || 'URGENT';
        break;
      case 'normal':
        backgroundColor = colors.status.normal;
        text = label || 'NORMAL';
        break;
      case 'pending':
        backgroundColor = colors.status.urgent;
        text = label || 'PENDING MATCH';
        break;
      case 'matching':
        backgroundColor = colors.tertiary;
        text = label || 'MATCHING';
        break;
      case 'matched':
        backgroundColor = colors.secondary;
        text = label || 'MATCHED';
        break;
      case 'in-transit':
        backgroundColor = colors.tertiary;
        text = label || 'IN TRANSIT';
        break;
      case 'delivered':
      case 'success':
        backgroundColor = colors.status.success;
        text = label || 'DELIVERED';
        break;
      case 'cancelled':
        backgroundColor = colors.textMuted;
        text = label || 'CANCELLED';
        break;
    }

    return { backgroundColor, text };
  };

  const { backgroundColor, text } = getBadgeStyle();

  return (
    <View style={[styles.badge, { backgroundColor }, style]}>
      <Text style={styles.text}>{text}</Text>
    </View>
  );
};

const styles = StyleSheet.create({
  badge: {
    paddingHorizontal: spacing.sm,
    paddingVertical: spacing.xs / 2,
    borderRadius: spacing.borderRadius.full,
    alignSelf: 'flex-start',
    justifyContent: 'center',
    alignItems: 'center',
  },
  text: {
    ...typography.styles.labelMd,
    fontSize: 10,
    color: colors.textLight,
  },
});
