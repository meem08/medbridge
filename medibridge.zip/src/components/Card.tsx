import React from 'react';
import { View, StyleSheet, ViewStyle } from 'react-native';
import { colors, spacing } from '../theme';

interface CardProps {
  children: React.ReactNode;
  style?: ViewStyle;
  isLowStock?: boolean;
  onPress?: () => void;
}

export const Card: React.FC<CardProps> = ({
  children,
  style,
  isLowStock = false,
  onPress,
}) => {
  const Container = onPress ? require('react-native').TouchableOpacity : View;

  return (
    <Container
      onPress={onPress}
      activeOpacity={0.9}
      style={[
        styles.card,
        isLowStock && styles.lowStockBorder,
        style,
      ]}
    >
      {children}
    </Container>
  );
};

const styles = StyleSheet.create({
  card: {
    backgroundColor: colors.surface,
    borderWidth: 1.5,
    borderColor: colors.border,
    borderRadius: spacing.borderRadius.md, // 8px rounding
    padding: spacing.md,
    marginBottom: spacing.md,
    // Soft shadow/depth system following design system (minimal shadow, outline is primary)
    shadowColor: colors.textSecondary,
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.05,
    shadowRadius: 2,
    elevation: 1,
  },
  lowStockBorder: {
    borderLeftWidth: 5,
    borderLeftColor: colors.primary, // Thick left border in Blood Red
  },
});
