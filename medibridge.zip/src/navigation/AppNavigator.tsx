import React from 'react';
import { createStackNavigator } from '@react-navigation/stack';
import { NavigationContainer } from '@react-navigation/native';

// Import Screens
import { SplashScreen } from '../screens/shared/SplashScreen';
import { ChooseRoleScreen } from '../screens/shared/ChooseRoleScreen';
import { LoginScreen } from '../screens/auth/LoginScreen';
import { SignUpScreen } from '../screens/auth/SignUpScreen';
import { HospitalDashboard } from '../screens/hospital/HospitalDashboard';
import { EmergencyRequestScreen } from '../screens/hospital/EmergencyRequestScreen';
import { BloodTrackingScreen } from '../screens/hospital/BloodTrackingScreen';
import { BloodInventoryScreen } from '../screens/hospital/BloodInventoryScreen';
import { DonorDashboard } from '../screens/donor/DonorDashboard';
import { BookAppointmentScreen } from '../screens/donor/BookAppointmentScreen';
import { DonationHistoryScreen } from '../screens/donor/DonationHistoryScreen';

export type RootStackParamList = {
  Splash: undefined;
  ChooseRole: undefined;
  Login: { role: 'hospital' | 'donor' };
  SignUp: { role: 'hospital' | 'donor' };
  HospitalMain: undefined;
  EmergencyRequest: undefined;
  BloodTracking: { requestId: string };
  BloodInventory: undefined;
  DonorMain: undefined;
  BookAppointment: undefined;
  DonationHistory: undefined;
};

const Stack = createStackNavigator<RootStackParamList>();

export const AppNavigator: React.FC = () => {
  return (
    <NavigationContainer>
      <Stack.Navigator
        initialRouteName="Splash"
        screenOptions={{
          headerShown: false,
          cardStyle: { backgroundColor: '#f7f9fc' },
        }}
      >
        {/* Shared / Auth Screens */}
        <Stack.Screen name="Splash" component={SplashScreen} />
        <Stack.Screen name="ChooseRole" component={ChooseRoleScreen} />
        <Stack.Screen name="Login" component={LoginScreen} />
        <Stack.Screen name="SignUp" component={SignUpScreen} />

        {/* Hospital Flow Screens */}
        <Stack.Screen name="HospitalMain" component={HospitalDashboard} />
        <Stack.Screen name="EmergencyRequest" component={EmergencyRequestScreen} />
        <Stack.Screen name="BloodTracking" component={BloodTrackingScreen} />
        <Stack.Screen name="BloodInventory" component={BloodInventoryScreen} />

        {/* Donor Flow Screens */}
        <Stack.Screen name="DonorMain" component={DonorDashboard} />
        <Stack.Screen name="BookAppointment" component={BookAppointmentScreen} />
        <Stack.Screen name="DonationHistory" component={DonationHistoryScreen} />
      </Stack.Navigator>
    </NavigationContainer>
  );
};
